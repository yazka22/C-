﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trackbar
{
    public partial class Form1 : Form
    {
        int valoareR = 0, valoareG = 0, valoareB = 0;
        public Form1()
        {
            InitializeComponent();
        }
        

        private void trackBarBlue_Scroll_1(object sender, EventArgs e)
        {
            valoareB = trackBarBlue.Value;
            textBoxBlue.Text = valoareB.ToString();
            trackBarBlue.BackColor = Color.FromArgb(valoareB, 0, 0);
            pictureBox.BackColor = Color.FromArgb(valoareR, valoareG, valoareB);
        }

        private void trackBarGreen_Scroll_1(object sender, EventArgs e)
        {
            valoareG = trackBarGreen.Value;
            textBoxGreen.Text = valoareG.ToString();
            trackBarGreen.BackColor = Color.FromArgb(valoareG, 0, 0);
            pictureBox.BackColor = Color.FromArgb(valoareR, valoareG, valoareB);
        }

        private void trackBarRed_Scroll_1(object sender, EventArgs e)
        {
            valoareR = trackBarRed.Value;
            textBoxRed.Text = valoareR.ToString();
            trackBarRed.BackColor = Color.FromArgb(valoareR, 0, 0);
            pictureBox.BackColor = Color.FromArgb(valoareR, valoareG, valoareB);
        }
    }
}
