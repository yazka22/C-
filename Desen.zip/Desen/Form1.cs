﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desen
{
    public partial class Form1 : Form
    {
        Graphics g;
        SolidBrush trafalet = new SolidBrush(Color.White);
        Int16 deseneaza = 0, optiune=1;
        Pen pensula = new Pen(Color.Black);
        Point coord_init, coord_finale;
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            Form.ActiveForm.Text = "X=" + e.X + "Y=" + e.Y;
            coord_finale.X = e.X;
            coord_finale.Y = e.Y;
            if (deseneaza == 1&& optiune==1)
            {
                g.DrawLine(pensula, coord_init, coord_finale);
                coord_init = coord_finale;
            }
            else if (deseneaza==1&& optiune==0)
            {
                g.FillRectangle(trafalet, e.X, e.Y, 20, 20);
            }
        }

        private void pictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            deseneaza = 1;
            coord_init.X = e.X;
            coord_init.Y = e.Y;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            g = pictureBox.CreateGraphics();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            optiune = 1;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            pensula.Color = colorDialog1.Color;
            pictureBox1.BackColor = colorDialog1.Color;
            optiune = 1;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            pictureBox.Refresh();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            pensula.Width = 5;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            pensula.Width = 2;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            pensula.Width = 10;
        }

        private void button_Sterge_Click(object sender, EventArgs e)
        {
            optiune = 0;
        }

        private void pictureBox_MouseUp(object sender, MouseEventArgs e)
        {
            deseneaza = 0;
        }
    }
}
